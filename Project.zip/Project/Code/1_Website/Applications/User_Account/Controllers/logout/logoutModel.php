<?php

class accountLogoutModel  
{	
	
}