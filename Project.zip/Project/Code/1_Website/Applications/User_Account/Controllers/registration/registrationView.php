<?php
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperView.php';

class registrationView extends applicationsSuperView
{

	
}
