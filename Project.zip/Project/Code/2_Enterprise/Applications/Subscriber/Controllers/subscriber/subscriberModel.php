<?php
require_once(FILE_ACCESS_CORE_CODE.'/Framework/MVC_superClasses_Core/viewSuperClass_Core/viewSuperClass_Core.php');
require_once FILE_ACCESS_CORE_CODE.'/Objects/Database/starfishDatabase.php';

class subscriberModel extends viewSuperClass_Core
{
	
}