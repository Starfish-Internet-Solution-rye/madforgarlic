<?php
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
require_once 'userDetailModel.php';
require_once 'userDetailView.php';

class userDetailController extends applicationsSuperController
{
	public function indexAction()
	{
	
		
	}
}