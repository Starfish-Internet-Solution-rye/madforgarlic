<?php
class userDetailModel 
{
	
	
}