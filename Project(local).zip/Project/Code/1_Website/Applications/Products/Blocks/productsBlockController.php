<?php
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
//----------------------------------------------------------

class articlesBlockController 
{

	 public function topTenArticles()
	 {
	 	return "top ten articles - CONTENT FRON ARICLES CONTROLLER";
	 }
	
	
}