<?php
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
require_once 'registrationView.php';
require_once 'registrationModel.php';


class registrationController extends applicationsSuperController
{
	
							
}
