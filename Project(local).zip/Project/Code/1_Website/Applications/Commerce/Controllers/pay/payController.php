<?php
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
require_once 'checkoutView.php';
require_once 'checkoutModel.php';


class payController extends applicationsSuperController
{

	public function indexAction()
	{

		
	}
	
	
}