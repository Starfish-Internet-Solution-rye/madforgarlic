editArea.add_lang("es",{
test_select: "select tag",
test_but: "test button"
});
