$(document).ready(function() {
	$('.menuList').jScrollPane();
});
