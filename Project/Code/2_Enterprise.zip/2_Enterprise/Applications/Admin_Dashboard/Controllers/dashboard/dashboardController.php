<?php 
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';

require_once 'dashboardModel.php';
require_once 'dashboardView.php';


class dashboardController extends applicationsSuperController
{
	public function indexAction()
	{
		
	}
}
?>