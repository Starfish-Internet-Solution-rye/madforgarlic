$(document).ready(function(){
	$('#delete_subscriber').click(function(){
		var atLeastOneIsChecked = $('input[name="subscriber_id[]"]:checked').length > 0;
		if(atLeastOneIsChecked)
			$('.deleteSubscriber').show();
	});
	
	$('.closeDialog').click(function(){
		$('.popupDialog').hide();
	});
});




